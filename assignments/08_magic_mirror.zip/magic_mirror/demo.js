
function setup() {

    createCanvas(800, 600)

    let names = ["brian", "quinn", "jesse"]

    let i = 0
    while (i < names.length) {

        print(names[i])

        i = i + 1
    }

    for (let i=0; i < names.length; i++) {
        print(names[i])
    }

}