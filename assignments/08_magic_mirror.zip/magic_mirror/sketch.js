let capture
let tracker

function setup() {

    createCanvas(800, 600)
    capture = createCapture(VIDEO)
    capture.size(800, 600)
    capture.hide()

    // tracker = new clm.tracker()
    // tracker.init()
    // tracker.start(capture.elt)    

}


function draw() {    

    background(0)
    image(capture, 0, 0, capture.width, capture.height)

    // let positions = tracker.getCurrentPosition()

    // noStroke()
    // fill(255)

    // let i = 0
    // while (i < positions.length) {

    //     ellipse(positions[i][0], positions[i][1], 4, 4)
    //     text(i, positions[i][0], positions[i][1])

    //     i += 1
    // }

    // if (positions.length > 0) {

    //     push()
    //     fill(255, 0, 0)
    //     ellipse(positions[27][0], positions[27][1], 20, 20)
    //     ellipse(positions[32][0], positions[32][1], 20, 20)
    //     pop()

    // }


}

