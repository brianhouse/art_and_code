let serial
let data = []

function setup() {

    createCanvas(windowWidth, windowHeight)

    // set up communication with the arduino
    serial = new p5.SerialPort()
    serial.list()
    serial.open('/dev/tty.usbmodem14101')       // change this line
    serial.on('data', gotData)

}


function gotData() {

    // put incoming data into the "data" array
    let newData = trim(serial.readLine())
    if (newData) {
        console.log(newData)
        if (newData > 400 && newData < 600) {
            if (data.length >= width/2) {
                data.shift()
            }
            data.push(newData)
        }
    }
}

function draw() {
    background(255)
    strokeWeight(2)

    // draw a vertex at every data point, mapped to the screen dimensions
    beginShape()
    for (let x=0; x<data.length; x++) {
        let y = map(data[x], 400, 600, height, 0)
        curveVertex(x, y)
    }
    endShape()
    
}